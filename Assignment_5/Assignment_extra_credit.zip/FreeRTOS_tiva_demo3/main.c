/* FreeRTOS 8.2 Tiva Demo
 *
 * main.c
 *
 * Andy Kobyljanec
 *
 * This is a simple demonstration project of FreeRTOS 8.2 on the Tiva Launchpad
 * EK-TM4C1294XL.  TivaWare driverlib sourcecode is included.
 */

#include "main.h"

#include <stdint.h>
#include <stdbool.h>
#include "drivers/pinout.h"
#include "utils/uartstdio.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "driverlib/debug.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/uart.h"
#include "driverlib/timer.h"
#include "driverlib/fpu.h"

// TivaWare includes
#include "driverlib/sysctl.h"
#include "driverlib/debug.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"

#include "i2cm_drv.h"
#include "driverlib/i2c.h"
#include "inc/hw_i2c.h"

// FreeRTOS includes
#include "FreeRTOSConfig.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

#define LED     0x01
#define TEMP    0X02

QueueHandle_t QUEUE;

uint8_t I2CByte1,I2CByte2;

struct Task
{
    TickType_t timestamp;
    float temperature;
    uint32_t led_count;
    char name[30];
    uint8_t tid;
};

struct Task global;

// Demo Task declarations
void LEDTask(void *pvParameters);
void TEMPTask(void *pvParameters);
void LOGGERTask(void *pvParameters);
void ALERTTask(void *pvParameters);

void InitTemp(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
    GPIOPinConfigure(GPIO_PB2_I2C0SCL);
    GPIOPinConfigure(GPIO_PB3_I2C0SDA);
    GPIOPinTypeI2C(GPIO_PORTB_BASE, GPIO_PIN_3);
    GPIOPinTypeI2CSCL(GPIO_PORTB_BASE, GPIO_PIN_2);
    SysCtlPeripheralDisable(SYSCTL_PERIPH_I2C0);
    SysCtlPeripheralReset(SYSCTL_PERIPH_I2C0);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C0);
    ROM_I2CMasterInitExpClk(I2C0_BASE, SYSTEM_CLOCK, true);
    UARTprintf("I2C Initialized\n");
}

// Based on examples provided by Prof. Rick
float ReadTemp(void)
{
    float temp_val;

    ROM_I2CMasterSlaveAddrSet(I2C0_BASE, 0x48, false);
    ROM_I2CMasterDataPut(I2C0_BASE, 0x00);
    ROM_I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_SINGLE_SEND);
    while(!ROM_I2CMasterBusy(I2C0_BASE));
    while(ROM_I2CMasterBusy(I2C0_BASE));

    ROM_I2CMasterSlaveAddrSet(I2C0_BASE, 0x48, true);
    ROM_I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_BURST_RECEIVE_START);
    while(!ROM_I2CMasterBusy(I2C0_BASE));
    while(ROM_I2CMasterBusy(I2C0_BASE));

    I2CByte1 = (uint8_t)ROM_I2CMasterDataGet(I2C0_BASE);
    ROM_I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_BURST_RECEIVE_CONT);
    while(!ROM_I2CMasterBusy(I2C0_BASE));
    while(ROM_I2CMasterBusy(I2C0_BASE));

    I2CByte2 = (uint8_t)ROM_I2CMasterDataGet(I2C0_BASE);
    ROM_I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_BURST_RECEIVE_FINISH);
    while(!ROM_I2CMasterBusy(I2C0_BASE));
    while(ROM_I2CMasterBusy(I2C0_BASE));

    temp_val = ((I2CByte1<<8)|I2CByte2) >> 4;
    temp_val *= 0.0625;
    return (temp_val);
}
uint32_t TickCounts=0;

// Main function
int main(void)
{
    global.led_count = 0;

    uint32_t output_clock_rate_hz;
    output_clock_rate_hz = ROM_SysCtlClockFreqSet(
                               (SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN |
                                SYSCTL_USE_PLL | SYSCTL_CFG_VCO_480),
                               SYSTEM_CLOCK);
    ASSERT(output_clock_rate_hz == SYSTEM_CLOCK);

    // Initialize the GPIO pins for the Launchpad
    PinoutSet(false, false);

    UARTStdioConfig(0, 115200, SYSTEM_CLOCK);

    if(xTaskCreate(LOGGERTask, (const portCHAR *)"Logger",
                500, (void *)&global, 1, NULL) != pdPASS)
    {
        UARTprintf("\nLogger Task not created");
    }

    if(xTaskCreate(LEDTask, (const portCHAR *)"LEDs",
                   500, (void *)&global, 1, NULL) != pdPASS)
    {
        UARTprintf("\nLed task not created");
    }

    if(xTaskCreate(TEMPTask, (const portCHAR *)"Temperature",
                    500, (void *)&global, 1, NULL) != pdPASS)
    {
        UARTprintf("\Temp Task not created");
    }

    if(xTaskCreate(ALERTTask, (const portCHAR *)"Alert",
                       500, (void *)&global, 1, NULL) != pdPASS)
    {
        UARTprintf("\Alert Task not created");
    }

    vTaskStartScheduler();
    while(1);
}

void LOGGERTask(void *pvParameters)
{
//    static struct Task Receive;
    static char msg[200];
    while(1)
    {
            if(((struct Task *)pvParameters)->tid == TEMP)
            {
                snprintf(msg,sizeof(msg),"Ticks:%d Temp:%f\n",((struct Task *)pvParameters)->timestamp,((struct Task *)pvParameters)->temperature);
                UARTprintf(msg);
                ((struct Task *)pvParameters)->tid = 0;
                vTaskDelay(1);
            }
            else if(((struct Task *)pvParameters)->tid == LED)
            {
                snprintf(msg,sizeof(msg),"Ticks:%d Led Count:%d Name:%s\n",((struct Task *)pvParameters)->timestamp,((struct Task *)pvParameters)->led_count,((struct Task *)pvParameters)->name);
                UARTprintf(msg);
                ((struct Task *)pvParameters)->tid = 0;
                vTaskDelay(1);
            }
    }
}

void LEDTask(void *pvParameters)
{
    static uint8_t toggle=0;
    while(1)
    {
        if((xTaskGetTickCount() % 100) == 0)
        {
            taskENTER_CRITICAL();
            ((struct Task *)pvParameters)->led_count += 1;
            ((struct Task *)pvParameters)->timestamp = xTaskGetTickCount();

            strcpy(((struct Task *)pvParameters)->name,"Yash Gupte");
            ((struct Task *)pvParameters)->tid = LED;

            taskEXIT_CRITICAL();

            toggle^=1;
            if(toggle == 1)
            {
                LEDWrite(0x01,0x01);
                LEDWrite(0x02,0x00);
            }
            else
            {
                LEDWrite(0x01,0x00);
                LEDWrite(0x02,0x02);
            }
            vTaskDelay(1);
        }
    }
}

void TEMPTask(void *pvParameters)
{
    InitTemp();
    while(1)
    {
        if((xTaskGetTickCount() % 1000)==0)
        {
            taskENTER_CRITICAL();
            ((struct Task *)pvParameters)->temperature = ReadTemp();
            ((struct Task *)pvParameters)->timestamp = xTaskGetTickCount();
            ((struct Task *)pvParameters)->tid = TEMP;

            taskEXIT_CRITICAL();
            vTaskDelay(1);
        }
    }
}

void ALERTTask(void *pvParameters)
{
    static char alert[200];

    while(1)
    {
        (((struct Task *)pvParameters)->temperature) = ReadTemp();
        if((((struct Task *)pvParameters)->temperature)>=24.000000)
        {
            taskENTER_CRITICAL();
                snprintf(alert,sizeof(alert),"ALERT!Temperature high: %f\n",((struct Task *)pvParameters)->temperature);
                UARTprintf(alert);
            taskEXIT_CRITICAL();

        }
        vTaskDelay(1);
    }
}


/*  ASSERT() Error function
 *
 *  failed ASSERTS() from driverlib/debug.h are executed in this function
 */
void __error__(char *pcFilename, uint32_t ui32Line)
{
    // Place a breakpoint here to capture errors until logging routine is finished
    while (1)
    {
    }
}

