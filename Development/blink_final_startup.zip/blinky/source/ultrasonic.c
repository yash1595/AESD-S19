
#include "main.h"

//#include "includes.h"
const double temp = 1.0/80.0;
volatile uint32_t pulse;
volatile uint8_t echowait=0;
static ultrasonic ultra_info;

void Captureinit()
{
  SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER2);
  SysCtlDelay(3);
  TimerConfigure(TIMER2_BASE, TIMER_CFG_PERIODIC_UP);
  TimerEnable(TIMER2_BASE,TIMER_A);
}

void ultrasonic_task(void *pvParameters)
{
  char Text_Print[150];
  Captureinit();

  while(1)
  {
      char str1[150] = {'D'};
      if(echowait != 1)
       {
       GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_3, GPIO_PIN_3);
       SysCtlDelay(266);
       GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_3, ~GPIO_PIN_3);
       while(echowait != 0);
       pulse =(uint32_t)(temp * pulse);
       pulse = pulse / 58;

      //ultrasonic_value();
      snprintf(Text_Print, sizeof(Text_Print), "%d",pulse);
      strcat(str1,Text_Print);
      strcat(str1,"D");
      strcpy(ultra_info.ultra_name,str1);
      bzero(str1,sizeof(str1));
      UARTprintf("\nTempTask Started and distance\n");

      if(xQueueSend(log_q,(void *)&ultra_info, 100) != pdTRUE)
         {
             UARTprintf("\nLog Error");
         }

    }
    vTaskDelay(575);

  }
}

uint32_t ultrasonic_task1()
{
  char Text_Print[150];
  Captureinit();

  while(1)
  {
      char str1[150] = {'D'};
      if(echowait != 1)
       {
       GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_3, GPIO_PIN_3);
       SysCtlDelay(266);
       GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_3, ~GPIO_PIN_3);
       while(echowait != 0);
       pulse =(uint32_t)(temp * pulse);
       pulse = pulse / 58;

       return pulse;
       }
   // vTaskDelay(575);
  }

}

void inputInt(){
  //Clear interrupt flag. Since we only enabled on this is enough
  GPIOIntClear(GPIO_PORTN_BASE, GPIO_PIN_2);

  /*
    If it's a rising edge then set he timer to 0
    It's in periodic mode so it was in some random value
  */
  if ( GPIOPinRead(GPIO_PORTN_BASE, GPIO_PIN_2) == GPIO_PIN_2){
    HWREG(TIMER2_BASE + TIMER_O_TAV) = 0; //Loads value 0 into the timer.
    TimerEnable(TIMER2_BASE,TIMER_A);
    echowait=1;
  }
  /*
    If it's a falling edge that was detected, then get the value of the counter
  */
  else{
    pulse = TimerValueGet(TIMER2_BASE,TIMER_A); //record value
    TimerDisable(TIMER2_BASE,TIMER_A);
    echowait=0;
  }
}



void ultrasonic_value()
{
    if(echowait != 1)
     {
     GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_3, GPIO_PIN_3);
     SysCtlDelay(266);
     GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_3, ~GPIO_PIN_3);
     while(echowait != 0);
     pulse =(uint32_t)(temp * pulse);
     pulse = pulse / 58;
     }
}
