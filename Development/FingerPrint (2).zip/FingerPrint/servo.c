#include "src/finger_print.h"

void servo_init(void)
{
  UARTprintf("Servo Has Started\n");
  SysCtlPWMClockSet(SYSCTL_PWMDIV_1);
  SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM0);
  SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOG);
  GPIOPinTypePWM(GPIO_PORTG_BASE, GPIO_PIN_1);
  GPIOPinConfigure(GPIO_PG1_M0PWM5);

}

void servo_pwm_config(void)
{
    UARTprintf("Setting parameters for servo\n");
    PWMGenConfigure(PWM0_BASE, PWM_GEN_2, PWM_GEN_MODE_UP_DOWN |PWM_GEN_MODE_NO_SYNC);
    PWMGenPeriodSet(PWM0_BASE, PWM_GEN_2, 100000);
    PWMPulseWidthSet(PWM0_BASE, PWM_OUT_5,PWMGenPeriodGet(PWM0_BASE, PWM_GEN_2) /6);
    PWMOutputState(PWM0_BASE, PWM_OUT_5_BIT, true);
    PWMGenEnable(PWM0_BASE, PWM_GEN_2);
//    while(1)
//    {
      UARTprintf("Normal\n");
      SysCtlDelay((ui32SysClock * 5) / 3);
      PWMOutputInvert(PWM0_BASE, PWM_OUT_5_BIT, true);
     // SysCtlDelay((ui32SysClock * 5) / 3);
    //  PWMOutputInvert(PWM0_BASE, PWM_OUT_5_BIT, false);
    //}
      flag1 = 0;
      PWMOutputInvert(PWM0_BASE, PWM_OUT_5_BIT, false);
}
