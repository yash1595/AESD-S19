/*
 * TempTask.c
 *
 *  Created on: Apr 10, 2019
 *      Author: mentor
 */




#include "src/finger_print.h"


void temp_task(void *pvParameters)
{
    char Text_Print[150];

    UARTprintf("\nTempTask Started\n");

    {
      static structure_sent temp_info;

      while(1)
        {
          char str[150] = {'T'};
       //
        //    if((xTaskGetTickCount())%1000 == 0)
          //  {
                //temp_info.tick_function_return_value = xTaskGetTickCount();
                //strcpy(temp_info.my_name, "Temperature");
                Temperature_Final_Value(&Celsius);
                snprintf(Text_Print, sizeof(Text_Print), "%d",(int)Celsius);
                 //UARTprintf("%s",Text_Print);
               //
                // strcpy(temp_info.temp_value_char, Text_Print);

                strcat(str,Text_Print);
                strcat(str,"T");
                strcpy(temp_info.my_name,str);
                bzero(str,sizeof(str));
                // strcpy(temp_info.final_string, Text_Print);
               // snprintf(Text_Print2, sizeof(Text_Print2), "%d",a);
               // strcpy(temp_info.temp_value_char,Text_Print2);
                  IntMasterEnable();
                  IntEnable(INT_UART3);
                  UARTIntEnable(UART3_BASE, UART_INT_RX | UART_INT_RT);
                if(xQueueSend(log_q,(void *)&temp_info, 100) != pdTRUE)
                {
                    UARTprintf("\nLog Error");
                }

                vTaskDelay(1000);
            //}
        }
    }
}

void Temperature_Final_Value(float *temp_final_Celsius)
{
    static structure_sent temp_info;
    ROM_I2CMasterSlaveAddrSet(I2C2_BASE, 0x48, true); //address of temp sensor
    ROM_I2CMasterDataPut(I2C2_BASE, 0x00); //in order to read from reg
    ROM_I2CMasterControl(I2C2_BASE, I2C_MASTER_CMD_SINGLE_SEND);
    ROM_I2CMasterControl(I2C2_BASE, I2C_MASTER_CMD_BURST_RECEIVE_START);
    while(!ROM_I2CMasterBusy(I2C2_BASE));
    while(ROM_I2CMasterBusy(I2C2_BASE));
    temperature_data_celsius[0] = (uint8_t)ROM_I2CMasterDataGet(I2C2_BASE);
    ROM_I2CMasterControl(I2C2_BASE, I2C_MASTER_CMD_BURST_RECEIVE_CONT);
    temperature_data_celsius[1] = (uint8_t)ROM_I2CMasterDataGet(I2C2_BASE);
    ROM_I2CMasterControl(I2C2_BASE, I2C_MASTER_CMD_BURST_RECEIVE_FINISH);
    *temp_final_Celsius = (((temperature_data_celsius[0] << 8) | temperature_data_celsius[1]) >> 4) * 0.0625;
    temp_info.temperature_value = Celsius;
    float Temp_Fehrenheit = (*temp_final_Celsius * 1.8) + 32;
    float Temp_Kelvin = *temp_final_Celsius + 273.15;

}
