/*
 * TIVA_C_HEADERS.h
 *
 *  Created on: Apr 17, 2019
 *      Author: yashm
 */

#ifndef SRC_TIVA_C_HEADERS_H_
#define SRC_TIVA_C_HEADERS_H_

#define YES (1)
#define NO  (0)



#endif /* SRC_TIVA_C_HEADERS_H_ */
