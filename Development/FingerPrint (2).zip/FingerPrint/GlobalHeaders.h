/*
 * GlobalHeaders.h
 *
 *  Created on: Apr 10, 2019
 *      Author: yashm
 */

#ifndef GLOBALHEADERS_H_
#define GLOBALHEADERS_H_

#include <stdint.h>
#include <stdbool.h>
#include "drivers/pinout.h"
#include "utils/uartstdio.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "driverlib/debug.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/uart.h"
#include "driverlib/timer.h"
#include "driverlib/fpu.h"

// TivaWare includes
#include "driverlib/sysctl.h"
#include "driverlib/debug.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"

#include "i2cm_drv.h"
#include "projdefs.h"
#include "portmacro.h"
#include "driverlib/i2c.h"
#include "inc/hw_i2c.h"
#include "FreeRTOS/include/FreeRTOS.h"
#include "FreeRTOS/include/queue.h"


//Variables to determine task in logger
#define LED     0x01
#define TEMP    0X02
//Functions for Temperature sensor
void InitTemp(void);
float ReadTemp(void);

#endif /* GLOBALHEADERS_H_ */
