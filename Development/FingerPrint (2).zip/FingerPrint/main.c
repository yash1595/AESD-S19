/* FreeRTOS 8.2 Tiva Demo
 *
 * main.c
 *
 * Andy Kobyljanec
 *
 * This is a simple demonstration project of FreeRTOS 8.2 on the Tiva Launchpad
 * EK-TM4C1294XL.  TivaWare driverlib sourcecode is included.
 */

#include "main.h"
#include "src/finger_print.h"

#include <stdint.h>
#include <stdbool.h>
#include "drivers/pinout.h"
#include "utils/uartstdio.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "driverlib/debug.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/uart.h"
#include "driverlib/timer.h"
#include "driverlib/fpu.h"

// TivaWare includes
#include "driverlib/sysctl.h"
#include "driverlib/debug.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"

#include "i2cm_drv.h"
#include "driverlib/i2c.h"
#include "inc/hw_i2c.h"

// FreeRTOS includes
#include "FreeRTOSConfig.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"


#define LED     0x01
#define TEMP    0X02

QueueHandle_t QUEUE;

uint8_t I2CByte1,I2CByte2;

struct Task
{
    TickType_t timestamp;
    float temperature;
    uint32_t led_count;
    char name[30];
    uint8_t tid;
};

struct Task global;


char c;

void my_uartHandler(void)
{
    uint32_t status = UARTIntStatus(UART3_BASE, true);
    UARTIntClear(UART3_BASE, status);

            c = UARTCharGet(UART3_BASE);

            if(c=='a')
            {
             flag =1;
             function_check();
            }
            else if(c=='n')
            {
              no_alert();
            }
            else if(c=='d')
            {
             //flag1 = 1;
            // function_check();
            // servo_init();
            // servo_pwm_config();
            }
            else if(c=='o')
            {
//              RelayInit(PORTL,PIN3);
//              RelayState(PORTL, PIN3,0);
            }
            else if(c=='r')
            {
                UARTprintf("*******************ALER************************\n");
                flag1 = 1;
                function_check();
            }
            else if(c=='f')
            {
                RelayInit(PORTL,PIN3);
                RelayState(PORTL, PIN3,0);
            }

}

// Main function
//Black - PA4 , Red - PA5
int main(void)
{

    //uint32_t output_clock_rate_hz;
    //ui32SysClock = SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN |SYSCTL_USE_OSC), SYSTEM_CLOCK);
      ui32SysClock =  SysCtlClockFreqSet(
              (SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN |
               SYSCTL_USE_PLL | SYSCTL_CFG_VCO_480),
              SYSTEM_CLOCK);
       SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
       SysCtlPeripheralEnable(SYSCTL_PERIPH_UART3);
       SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

       GPIOPinConfigure(GPIO_PA0_U0RX);
       GPIOPinConfigure(GPIO_PA1_U0TX);
       GPIOPinConfigure(GPIO_PA4_U3RX);
       GPIOPinConfigure(GPIO_PA5_U3TX);

       GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_4 | GPIO_PIN_5 );

       UARTConfigSetExpClk(UART0_BASE, ui32SysClock, 115200,(UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |UART_CONFIG_PAR_NONE));
       UARTConfigSetExpClk(UART3_BASE, ui32SysClock, 115200,(UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |UART_CONFIG_PAR_NONE));

       //Configure Trigger pin
         SysCtlPeripheralEnable(SYSCTL_PERIPH_GPION);
         SysCtlDelay(3);
         GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_3);

         //Configure Echo pin
         SysCtlPeripheralEnable(SYSCTL_PERIPH_GPION);
         SysCtlDelay(3);
         GPIOPinTypeGPIOInput(GPIO_PORTN_BASE, GPIO_PIN_2);
         GPIOIntEnable(GPIO_PORTN_BASE, GPIO_PIN_2);
         GPIOIntTypeSet(GPIO_PORTN_BASE, GPIO_PIN_2,GPIO_BOTH_EDGES);
         GPIOIntRegister(GPIO_PORTN_BASE,inputInt);
      //   servo_init();
//
      ASSERT(ui32SysClock == SYSTEM_CLOCK);

         // Initialize the GPIO pins for the Launchpad
         PinoutSet(false, false);

       //  UARTStdioConfig(0, 115200, SYSTEM_CLOCK);
    UARTStdioConfig(0, 115200, ui32SysClock);
    i2c_init(); //I2C initialisation by portb and temp i2c by address0x48
    //FingerPrintInit();
    //CheckFingerPrint();
   xTaskCreate(logger, (const portCHAR *)"Logs",500, NULL, 1, NULL); //logger task initiated
   xTaskCreate(temp_task, (const portCHAR *)"Temp",500, NULL, 1, NULL); //temp task initiated
 //  xTaskCreate(ultrasonic_task, (const portCHAR *)"Ultra",500, NULL, 1, NULL); //temp task initiated
   xTaskCreate(fingerprint_task, (const portCHAR *)"Finger",500, NULL, 1, NULL); //temp task initiated
        // UARTprintf("Hey\n");


 //  UARTprintf("Uart5 Initialized\n");
   vTaskStartScheduler();
       return 0;
}


/*  ASSERT() Error function
 *
 *  failed ASSERTS() from driverlib/debug.h are executed in this function
 */
void __error__(char *pcFilename, uint32_t ui32Line)
{
    // Place a breakpoint here to capture errors until logging routine is finished
    while (1)
    {
    }
}

