#include "main.h"

void startup_test_temperature()
{
    //temp
    Temperature_Final_Value(&Celsius);
    if(Celsius == 0)
    {
     UARTprintf("Error in Temp\n");
     flag_startup = 1;
    }
    else
    {
     flag_startup = 0;
    }

}




//void startup_test_fingerprint()
//{
//   // CommandSend(1,CMD_CMOS_LED);
//   // CommandResponse(CMD_CMOS_LED);
//
////    if(flag_fingerprint == 0)
////    {
////        flag_startup =1;
////        UARTprintf("Alert from fingerprint\n");
////    }
////    else
////    {
////        flag_startup = 0;
////    }
//}

void startup()
{
    startup_test_temperature();
 //   startup_test_fingerprint();
   // startup_test_ultrasonic();

    flag_startup = CheckTest();
    if(flag_startup == 1)
    {
        UARTprintf("\n****Exiting the system, Startup Failed****\n");
    }
    else
    {
        UARTprintf("\n****Startup Success, Starting System****\n");
    }

}
