/*
 * LogQueue.c
 *
 *  Created on: Apr 10, 2019
 *      Author: mentor
 */

#include "includes.h"

volatile char* convert_structure;

void logger(void *pvParameters)
{
    int length;
    static char Text_Print[200];
    log_q = xQueueCreate(10, sizeof(structure_sent));
    static structure_sent log_info;

    if(log_q == 0)
    {
     UARTprintf("\nLOG Queue Creation Failed");
    }

    else
    {
     UARTprintf("\nLOG Queue Created\n");
    }

    while(1)
    {
        if(xQueueReceive(log_q, (void *)&log_info, 100) == pdTRUE)
        {

         convert_structure = (uint8_t *)&log_info;
         UART_Communication(convert_structure,sizeof(structure_sent));
        }
    }

}

void UART_Communication(char *convert_structure, int length)
{
    UARTprintf("Length is %d\n",length);
    while(length != 0)
    {
      UARTCharPut(UART0_BASE, *convert_structure);
      UARTCharPut(UART3_BASE, *convert_structure);
      convert_structure++;
      //UARTprintf("\nLength of convert_structure is %d \n",convert_structure);
      length--;
//      if(length == 37)
//      {
//       UARTprintf("\n");
//      }

    }
}
