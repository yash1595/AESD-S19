/*
 * LogQueue.c
 *
 *  Created on: Apr 10, 2019
 *      Author: mentor
 */

#include "includes.h"

volatile char* convert_structure;

void logger(void *pvParameters)
{
    int length;
    static char Text_Print[200];
    log_q = xQueueCreate(10, sizeof(structure_sent));
    static structure_sent log_info;

    if(log_q == 0)
    {
     UARTprintf("\nLOG Queue Creation Failed");
    }

    else
    {
     UARTprintf("\nLOG Queue Created\n");
    }

    while(1)
    {
        if(xQueueReceive(log_q, (void *)&log_info, 100) == pdTRUE)
        {

         convert_structure = (uint8_t *)&log_info;
         UART_Communication(convert_structure,sizeof(structure_sent));
        }
    }

}

void UART_Communication(char *convert_structure, int length)
{
  //  UARTCharPut(UART3_BASE, '2');
   // UARTprintf("Length is %d\n",length);
    while(length != 0)
    {
      UARTCharPut(UART0_BASE, *convert_structure);
      UARTCharPut(UART3_BASE, *convert_structure);
      //UARTCharPut(UART3_BASE, '2');
      convert_structure++;
      length--;
//      if(length == 37)
//      {
//       UARTprintf("\n");
//      }
//
    }
}




void function_check()
{
    if(flag == 0)
    {
     UARTprintf("Alert received from Temperature\n");
     temp_func();
    }
}
