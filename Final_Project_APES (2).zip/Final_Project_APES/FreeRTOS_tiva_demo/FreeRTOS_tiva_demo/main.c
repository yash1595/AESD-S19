/* FreeRTOS 8.2 Tiva Demo
 *
 * main.c
 *
 * Andy Kobyljanec
 * Reference : https://e2e.ti.com/support/microcontrollers/other/f/908/t/468677 for I2C communication
 * Demo Code of Timers from TI
 * if project shows negative temperature, try rebuilding the project after doing clean
 * This is a simple demonstration project of FreeRTOS 8.2 on the Tiva Launchpad
 * EK-TM4C1294XL.  TivaWare driverlib sourcecode is included.
 */

#include "includes.h"




char c;

void my_uartHandler(void)
{
    uint32_t status = UARTIntStatus(UART3_BASE, true);
    UARTIntClear(UART3_BASE, status);
      // while(1)
        //{
            c = UARTCharGet(UART3_BASE);
          //  UARTprintf("Hello : %c ",c);
            UARTCharPut(UART0_BASE, c);
            if(c=='a')
            {
             flag =1;
            }
            function_check();
        //}
    //cThisChar = UARTCharGet(UART3_BASE);
}
int main(void)
{

    ui32SysClock = SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN |SYSCTL_USE_OSC), 25000000);

    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART3);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);
    GPIOPinConfigure(GPIO_PA4_U3RX);
    GPIOPinConfigure(GPIO_PA5_U3TX);

    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_4 | GPIO_PIN_5 );

    UARTConfigSetExpClk(UART0_BASE, ui32SysClock, 115200,(UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |UART_CONFIG_PAR_NONE));
    UARTConfigSetExpClk(UART3_BASE, ui32SysClock, 115200,(UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |UART_CONFIG_PAR_NONE));

    //ASSERT(ui32SysClock == SYSTEM_CLOCK);
  //  PinoutSet(0,0);

    UARTStdioConfig(0, 115200, ui32SysClock);
    i2c_init(); //I2C initialisation by portb and temp i2c by address0x48

    xTaskCreate(logger, (const portCHAR *)"Logs",500, NULL, 1, NULL); //logger task initiated
    xTaskCreate(temp_task, (const portCHAR *)"Temp",500, NULL, 1, NULL); //temp task initiated
    vTaskStartScheduler();
    return 0;
}


void __error__(char *pcFilename, uint32_t ui32Line)
{
    // Place a breakpoint here to capture errors until logging routine is finished
    while (1)
    {
    }
}

