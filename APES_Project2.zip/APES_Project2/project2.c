
#include "main.h"

//Variables defined
char * uart_driver = "/dev/ttyO2";
struct termios *my_term;
void termios_setup(struct termios * my_term, int descriptor);
char arr[20],temp[10],temp1[20];
int flag = 0,fd,flag1=0;
char send1[5] = {'a'};
char send2[5] = {'n'};
char send3[4] = {'d'};
char send4[4] = {'o'};

void uart_setup()				//uart driver setup
{
    fd = open(uart_driver, O_RDWR, O_SYNC, O_NOCTTY);
    if(fd < 0)
    {
    	perror("Error opening uart driver");
    }

    my_term  = (struct termios *)malloc(sizeof(struct termios));

    termios_setup(my_term, fd);
}
void termios_setup(struct termios * my_term, int descriptor)
{
    tcgetattr(descriptor, my_term);
    my_term->c_iflag &= ~(IGNBRK | ICRNL | INLCR | PARMRK | ISTRIP | IXON);
    my_term->c_oflag &= ~OPOST;
    my_term->c_lflag &= ~(ECHO | ECHONL | ICANON | IEXTEN | ISIG);
    my_term->c_cflag |= CS8 | CLOCAL;

    cfsetispeed(my_term, B115200);
    cfsetospeed(my_term, B115200);

    if(tcsetattr(descriptor, TCSAFLUSH, my_term) < 0)
    {
        perror("ERROR in set attr\n");
    }

    while(1)
    {
        read(fd,&arr,sizeof(arr));
        if(arr[0]=='T' || arr[0]=='D')
        {
            if((arr[0])=='T')
            {
             printf("T is checked\n");
             read_temp();
            }
            else
            {
             printf("D is checked\n");
             read_distance();
            }
        }
    }

}

void read_temp(void)
{
  //uint8_t temp_value_final[5];
  uint8_t t_data[5];
  int i = 1;
  while(arr[i]!='T')
  {
    t_data[i-1]=(arr[i]);
    printf("t_data :%c",t_data[i-1]);
    i+=1;
    printf("Value of i: %d",i);
  }

  uint8_t temp_val = atoi(t_data);
  printf("Final Temp value %d\n",temp_val);
  if(temp_val > 26)
  {
    printf("Alert is set\n");
    flag = 1;
  }
  if(flag == 1)
  {
   write(fd,&send1, sizeof(send1));
   printf("%s\n",send1);
   flag =0;
  }
  else
  {
   write(fd,&send2, sizeof(send2));
   printf("%s\n",send2);

  }
}


void read_distance(void)
{
  //uint8_t temp_value_final[5];
  uint8_t d_data[5];
  int i = 1;
  while(arr[i]!='D')
  {
    d_data[i-1]=(arr[i]);
    printf("d_data :%c",d_data[i-1]);
    i+=1;
    printf("Value of i: %d",i);
  }

  uint8_t distance_val = atoi(d_data);
  printf("Final Distance value %d\n",distance_val);
   if(distance_val < 5 || distance_val > 100  )
  {
    printf("Alert is set\n");
    flag1 = 1;
  }
  if(flag1 == 1)
  {
   write(fd,&send3, sizeof(send3));
   printf("%s\n",send3);
   flag1 =0;
  }
  else
  {
   write(fd,&send4, sizeof(send4));
   printf("%s\n",send4);

  }
}

int main()
{
	uart_setup();
//	printf("Value of flag :%d\n",flag);

}
