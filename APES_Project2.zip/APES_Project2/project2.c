
#include "main.h"

//Variables defined
char * uart_driver = "/dev/ttyO2";
struct termios *my_term;
void termios_setup(struct termios * my_term, int descriptor);
char arr[20],temp[10],temp1[20];
int flag = 0,fd;
char send1[] = {'a'};


void uart_setup()				//uart driver setup
{
    fd = open(uart_driver, O_RDWR, O_SYNC, O_NOCTTY);
    if(fd < 0)
    {
    	perror("Error opening uart driver");
    }

    my_term  = (struct termios *)malloc(sizeof(struct termios));

    termios_setup(my_term, fd);
}
void termios_setup(struct termios * my_term, int descriptor)
{
    tcgetattr(descriptor, my_term);
    my_term->c_iflag &= ~(IGNBRK | ICRNL | INLCR | PARMRK | ISTRIP | IXON);
    my_term->c_oflag &= ~OPOST;
    my_term->c_lflag &= ~(ECHO | ECHONL | ICANON | IEXTEN | ISIG);
    my_term->c_cflag |= CS8 | CLOCAL;

    cfsetispeed(my_term, B115200);
    cfsetospeed(my_term, B115200);

    if(tcsetattr(descriptor, TCSAFLUSH, my_term) < 0)
    {
        perror("ERROR in set attr\n");
    }

		read(fd,&arr,3);
		if(arr[2]=='T')
		{
			strncpy(temp,arr,2);
		}
		snprintf(temp1,sizeof(temp1),"20");
		printf("Threshold Value:%s\n",temp1);
		printf("Original Value:%s\n",temp);

		if(temp > temp1 )
		 {
		 	printf("Alert is set\n");
		 	flag = 1;
		 }

}
int main()
{
	uart_setup();
	printf("Value of flag :%d\n",flag);
	if(flag == 1)
	{
		write(fd,&send1, sizeof(send1));
	 	printf("%s\n",send1);
	 }
}
