//Includes
#include <stdint.h>
#include <stdbool.h>
#include "main.h"
#include "drivers/pinout.h"
#include "utils/uartstdio.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "driverlib/debug.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/uart.h"
#include "driverlib/timer.h"
#include "driverlib/fpu.h"

// TivaWare includes
#include "driverlib/sysctl.h"
#include "driverlib/debug.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"

#include "i2cm_drv.h"
#include "driverlib/i2c.h"
#include "inc/hw_i2c.h"

// FreeRTOS includes
#include "FreeRTOSConfig.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"



//Includes
#include <stdint.h>
#include <stdbool.h>
#include "main.h"
#include "drivers/pinout.h"
#include "utils/uartstdio.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "driverlib/debug.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/uart.h"
#include "driverlib/timer.h"
#include "driverlib/fpu.h"

// TivaWare includes
#include "driverlib/sysctl.h"
#include "driverlib/debug.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"

#include "i2cm_drv.h"
#include "driverlib/i2c.h"
#include "inc/hw_i2c.h"

// FreeRTOS includes
#include "FreeRTOSConfig.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

#include <stdint.h>
#include <stdbool.h>
#include "stdlib.h"
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_timer.h"
#include "inc/hw_uart.h"
#include "inc/hw_gpio.h"
#include "inc/hw_pwm.h"
#include "inc/hw_types.h"
#include "driverlib/pin_map.h"

#include "driverlib/timer.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/sysctl.h"
#include "driverlib/uart.h"
#include "driverlib/udma.h"
#include "driverlib/pwm.h"
#include "driverlib/ssi.h"
#include "driverlib/systick.h"

#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include "driverlib/inc/tm4c1294ncpdt.h"
#include "driverlib/sysctl.h"


#include <stdint.h>
#include <stdbool.h>
#include "stdlib.h"
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_timer.h"
#include "inc/hw_uart.h"
#include "inc/hw_gpio.h"
#include "inc/hw_pwm.h"
#include "inc/hw_types.h"
#include "driverlib/pin_map.h"

#include "driverlib/timer.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/sysctl.h"
#include "driverlib/uart.h"
#include "driverlib/udma.h"
#include "driverlib/pwm.h"
#include "driverlib/ssi.h"
#include "driverlib/systick.h"

#include <string.h>

typedef struct {
    char my_name[250];
    float temperature_value;
}structure_sent;

typedef struct {
    char ultra_name[250];
    //float ultra_distance;
}ultrasonic;

uint8_t temperature_data_celsius[30];
float Celsius;
uint32_t ui32SysClock;
char cThisChar;
int flag,flag1;
//uint8_t temperature_data_celsius[30];
QueueHandle_t log_q,log_q1;


void inputInt();
void Captureinit();
void InitConsole(void);
void ultrasonic_task(void *pvParameters);

//Function Prototypes
void demoLEDTask(void *pvParameters);
void i2c_init();
void temp_task(void *pvParameters);
void logger(void *pvParameters);
void __error__(char *pcFilename, uint32_t ui32Line);
void UART_Communication1(char *convert_structure1, int length);
void UART_Communication(char *convert_structure, int length);


#define PORTA   GPIO_PORTA_BASE
#define PORTB   GPIO_PORTB_BASE
#define PORTC   GPIO_PORTC_BASE
#define PORTD   GPIO_PORTD_BASE
#define PORTE   GPIO_PORTE_BASE
#define PORTF   GPIO_PORTF_BASE
#define PORTG   GPIO_PORTG_BASE
#define PORTH   GPIO_PORTH_BASE
#define PORTL   GPIO_PORTL_BASE

#define PIN0    GPIO_PIN_0
#define PIN1    GPIO_PIN_1
#define PIN2    GPIO_PIN_2
#define PIN3    GPIO_PIN_3
#define PIN4    GPIO_PIN_4
#define PIN5    GPIO_PIN_5
#define PIN6    GPIO_PIN_6
#define PIN7    GPIO_PIN_7


void RelayInit(uint32_t Port,uint32_t Pin);     // (PORTH,2)
void RelayState(uint32_t PORT,uint32_t Pin,uint8_t state);
void servo_init(void);
void servo_pwm_config(void);


uint32_t sysclock,sysclock1;
uint32_t ui32Period;

//#include <stdint.h>
//#include <stdbool.h>
//#include "inc/hw_ints.h"
//#include "inc/hw_memmap.h"
//#include "inc/hw_types.h"
//#include "driverlib/debug.h"
//#include "driverlib/gpio.h"
//#include "driverlib/pin_map.h"
//#include "driverlib/sysctl.h"
//#include "driverlib/pwm.h"
//#include "utils/uartstdio.h"
//#include "driverlib/uart.h"
////Includes
//#include <stdint.h>
//#include <stdbool.h>
//
////#include "drivers/pinout.h"
//#include "utils/uartstdio.h"
//
//#include <stdlib.h>
//#include <stdio.h>
//#include <string.h>
//#include "inc/hw_ints.h"
//#include "inc/hw_memmap.h"
//#include "driverlib/debug.h"
//#include "driverlib/gpio.h"
//#include "driverlib/interrupt.h"
//#include "driverlib/pin_map.h"
//#include "driverlib/uart.h"
//#include "driverlib/timer.h"
//#include "driverlib/fpu.h"
//
//// TivaWare includes
//#include "driverlib/sysctl.h"
//#include "driverlib/debug.h"
//#include "driverlib/rom.h"
//#include "driverlib/rom_map.h"
